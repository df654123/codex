#!/usr/bin/env python3
"""Serve the supplied index.html only; Python standard library, no downloads."""
import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import ipaddress
import os
from pathlib import Path
import re
import socket
from socketserver import TCPServer
import subprocess
import sys
from urllib.parse import urlsplit


DEFAULT_PORT = 8765


class PageServer(ThreadingHTTPServer):
    def server_bind(self):
        # HTTPServer normally calls getfqdn here. Numeric local addresses need
        # no DNS, especially when the school's Wi-Fi has no internet service.
        TCPServer.server_bind(self)
        self.server_name = self.server_address[0]
        self.server_port = self.server_address[1]


class PageHandler(BaseHTTPRequestHandler):
    server_version = "OfflineLearning"
    sys_version = ""
    protocol_version = "HTTP/1.0"

    def _respond(self, status, body, content_type="text/plain; charset=utf-8", allow=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Connection", "close")
        if allow:
            self.send_header("Allow", "GET, HEAD")
        self.end_headers()
        self.close_connection = True
        if self.command != "HEAD":
            self.wfile.write(body)

    def _serve_page(self):
        try:
            target = urlsplit(self.path)
        except ValueError:
            self._respond(400, b"Bad request target.\n")
            return
        if target.scheme or target.netloc or target.fragment:
            self._respond(400, b"Bad request target.\n")
        elif target.path in ("/", "/index.html"):
            self._respond(200, self.server.page_bytes, "text/html; charset=utf-8")
        elif target.path == "/healthz":
            self._respond(200, b'{"status":"ok"}\n', "application/json; charset=utf-8")
        else:
            # Do not decode or resolve a request path against the filesystem.
            self._respond(404, b"Not found.\n")

    def do_GET(self):
        self._serve_page()

    def do_HEAD(self):
        self._serve_page()

    def _method_not_allowed(self):
        self._respond(405, b"Method not allowed.\n", allow=True)

    do_POST = _method_not_allowed
    do_PUT = _method_not_allowed
    do_PATCH = _method_not_allowed
    do_DELETE = _method_not_allowed
    do_OPTIONS = _method_not_allowed
    do_TRACE = _method_not_allowed
    do_CONNECT = _method_not_allowed

    def log_message(self, _format, *_args):
        # Keep the window readable; the helper has no access log or learner log.
        pass


def create_server(index_path, *, port=DEFAULT_PORT, lan=False):
    """Load one fixed UTF-8 page before opening a loopback/LAN listener."""
    page_bytes = Path(index_path).read_bytes()
    page_bytes.decode("utf-8")
    server = PageServer(("0.0.0.0" if lan else "127.0.0.1", port), PageHandler)
    server.daemon_threads = True
    server.page_bytes = page_bytes
    return server


def _local_command(command):
    """Read OS interface settings only; never run a shell or contact a host."""
    try:
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=4, check=False)
        if result.returncode == 0:
            # Addresses and the IPv4/inet labels are ASCII in these OS outputs.
            return result.stdout.decode("ascii", errors="ignore")
    except (OSError, subprocess.TimeoutExpired):
        pass
    return ""


def local_ipv4_addresses():
    """Enumerate local interfaces, with no DNS, remote UDP probe, or scan."""
    candidates = []
    if sys.platform.startswith("linux"):
        try:
            import fcntl
            import struct
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as control:
                for _index, name in socket.if_nameindex():
                    request = struct.pack("256s", name.encode("utf-8")[:15])
                    try:
                        flags = fcntl.ioctl(control.fileno(), 0x8913, request)  # SIOCGIFFLAGS
                        if not struct.unpack_from("H", flags, 16)[0] & 1:  # IFF_UP
                            continue
                        address = fcntl.ioctl(control.fileno(), 0x8915, request)  # SIOCGIFADDR
                        candidates.append(socket.inet_ntoa(address[20:24]))
                    except OSError:
                        continue
        except (ImportError, OSError):
            pass
    elif sys.platform == "win32":
        executable = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "ipconfig.exe")
        for line in _local_command([executable]).splitlines():
            if "ipv4" in line.lower():
                candidates.extend(re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", line))
    elif sys.platform == "darwin" or "bsd" in sys.platform:
        candidates.extend(re.findall(r"(?m)^\s*inet\s+((?:\d{1,3}\.){3}\d{1,3})\b", _local_command(["/sbin/ifconfig"])))

    addresses = set()
    for candidate in candidates:
        try:
            address = ipaddress.IPv4Address(candidate)
        except ipaddress.AddressValueError:
            continue
        if not (address.is_loopback or address.is_unspecified or address.is_multicast or address.is_link_local) and str(address) != "255.255.255.255":
            addresses.add(address)
    return [str(address) for address in sorted(addresses)]


def _port(value):
    try:
        port = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError("端口须为数字，例如 8765。")
    if not 0 <= port <= 65535:
        raise argparse.ArgumentTypeError("端口须在 0 到 65535 之间。")
    return port


def main(argv=None):
    parser = argparse.ArgumentParser(description="只读提供同文件夹的 index.html；默认仅本机，--lan 开启同一 Wi-Fi 访问。")
    parser.add_argument("--lan", action="store_true", help="监听 0.0.0.0，允许同一局域网的设备访问")
    parser.add_argument("--port", type=_port, default=DEFAULT_PORT, help="端口（默认 8765）")
    args = parser.parse_args(argv)
    index_path = Path(__file__).resolve().with_name("index.html")
    try:
        server = create_server(index_path, port=args.port, lan=args.lan)
    except (OSError, UnicodeError) as error:
        print("启动失败：请确认本文件旁有完整的 UTF-8 index.html，且所选端口未被其他程序占用。", file=sys.stderr)
        print(str(error), file=sys.stderr)
        return 1

    port = server.server_address[1]
    print("\n英语学习站已启动。学习记录保存在各自浏览器中。")
    print("本机打开：http://127.0.0.1:{}/".format(port))
    if args.lan:
        print("\n手机与这台电脑连接同一个 Wi-Fi，再打开电脑对应的地址：")
        addresses = local_ipv4_addresses()
        for address in addresses:
            print("  http://{}:{}/".format(address, port))
        if not addresses:
            print("未能自动列出局域网地址。请在电脑的网络设置中查看当前 Wi-Fi 的 IPv4 地址。")
            print("在手机输入 http://该IPv4地址:{}/".format(port))
        elif len(addresses) > 1:
            print("有多个网卡地址时，请使用电脑当前 Wi-Fi 对应的 IPv4 地址。")
        print("电脑和此窗口须保持运行；不需要连接互联网。")
    else:
        print("当前仅本机可访问。如需同一 Wi-Fi 的手机访问，请加 --lan 重新启动。")
    print("按 Ctrl+C 停止。更换 index.html 后请重新启动。\n", flush=True)
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        print("\n学习站已停止。")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
