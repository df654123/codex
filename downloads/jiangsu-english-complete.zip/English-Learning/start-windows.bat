@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul 2>&1
title Jiangsu English - Local Wi-Fi

rem Only use an existing Python runtime. Do not install or download one.
set "PYTHON_MANAGER_AUTOMATIC_INSTALL=false"
set "PYLAUNCHER_ALLOW_INSTALL="
set "PYLAUNCHER_ALWAYS_INSTALL="
set "PYLAUNCHER_DRYRUN="

pushd "%~dp0"
if errorlevel 1 (
    echo 无法进入离线包文件夹。请先完整解压，再运行此文件。
    echo Cannot open the package folder. Extract the whole package first.
    pause
    exit /b 1
)

if not exist "index.html" goto missing_files
if not exist "serve.py" goto try_powershell

py -3 -c "from http.server import ThreadingHTTPServer" >nul 2>&1
if not errorlevel 1 goto use_py
python -c "from http.server import ThreadingHTTPServer" >nul 2>&1
if not errorlevel 1 goto use_python

:try_powershell
set "offline_share_ps=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%offline_share_ps%" goto use_powershell
echo 未找到可用的 Python 3 或 Windows PowerShell；无法启动局域网分享。
echo 这台电脑仍可直接用浏览器打开 index.html，无需 Python。
echo For desktop use, open the extracted index.html directly in a browser.
echo No software has been installed or downloaded.
set "offline_share_exit=1"
goto finished

:use_py
call :notice
py -3 "serve.py" --lan %*
set "offline_share_exit=%errorlevel%"
goto finished

:use_python
call :notice
python "serve.py" --lan %*
set "offline_share_exit=%errorlevel%"
goto finished

:use_powershell
set "JIANGSU_LEARNING_PORT=8765"
if "%~1"=="" goto run_powershell
if /I not "%~1"=="--port" goto bad_port
if "%~2"=="" goto bad_port
if not "%~3"=="" goto bad_port
set "JIANGSU_LEARNING_PORT=%~2"

:run_powershell
call :notice
echo 未使用 Python；正在使用 Windows 自带的 PowerShell 只读分享。
rem Literal command, not a script file. Read one fixed page before opening a listener.
rem Read only available bytes, up to 8 KiB and 5 s per header, 16 pending clients.
rem Never open a file chosen by the URL. Each response closes the TCP connection.
"%offline_share_ps%" -NoLogo -NoProfile -NonInteractive -Command ^
  "$ErrorActionPreference='Stop'; $listener=$null; $queue=[Collections.ArrayList]::new(); try {" ^
  "if($PSVersionTable.PSVersion -lt [version]'5.1'){throw 'Windows PowerShell 5.1 is required.'};" ^
  "$port=0; if(-not [int]::TryParse($env:JIANGSU_LEARNING_PORT,[ref]$port) -or $port -lt 0 -or $port -gt 65535){throw 'Invalid --port; use 0 to 65535.'};" ^
  "$page=[IO.File]::ReadAllBytes('index.html'); $ascii=[Text.Encoding]::ASCII; $wire=[Text.Encoding]::GetEncoding(28591);" ^
  "$nl=[string][char]13+[char]10; $q=[char]34; $health=$ascii.GetBytes('{'+$q+'status'+$q+':'+$q+'ok'+$q+'}'+[char]10);" ^
  "$listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Any,$port); $listener.ExclusiveAddressUse=$true; $listener.Start(24); $port=$listener.LocalEndpoint.Port;" ^
  "Write-Host ('本机打开：http://127.0.0.1:'+ $port +'/'); $ips=@(); try {" ^
  "foreach($adapter in [Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces()){if($adapter.OperationalStatus -ne 'Up'){continue};" ^
  "foreach($entry in $adapter.GetIPProperties().UnicastAddresses){$addr=$entry.Address; if($addr.AddressFamily -eq 'InterNetwork' -and -not [Net.IPAddress]::IsLoopback($addr) -and -not $addr.ToString().StartsWith('169.254.')){$ips+=$addr.ToString()}}}" ^
  "} catch {}; foreach($ip in ($ips | Sort-Object -Unique)){Write-Host ('手机候选地址：http://'+$ip+':'+$port+'/')};" ^
  "if($ips.Count -eq 0){Write-Host ('请在网络设置查看电脑 Wi-Fi 的 IPv4，手机打开 http://该IP:'+ $port +'/')} elseif($ips.Count -gt 1){Write-Host '请选择电脑当前 Wi-Fi 对应的 IPv4 地址。'};" ^
  "while($true){while($queue.Count -lt 16 -and $listener.Pending()){$client=$null; try {$client=$listener.AcceptTcpClient(); $stream=$client.GetStream(); $stream.ReadTimeout=1000; $stream.WriteTimeout=5000;" ^
  "[void]$queue.Add(@{client=$client;stream=$stream;buffer=[byte[]]::new(8192);used=0;clock=[Diagnostics.Stopwatch]::StartNew()})} catch {if($client){$client.Close()}; break}};" ^
  "for($i=$queue.Count-1;$i -ge 0;$i--){$job=$queue[$i]; try {" ^
  "if($job.clock.ElapsedMilliseconds -ge 5000){throw 'header timeout'}; $n=[Math]::Min($job.client.Available,8192-$job.used); if($n -le 0){continue};" ^
  "$got=$job.stream.Read($job.buffer,$job.used,$n); if($got -le 0){throw 'closed'}; $job.used+=$got; $header=$wire.GetString($job.buffer,0,$job.used);" ^
  "if(-not $header.Contains($nl+$nl)){if($job.used -eq 8192){throw 'header too large'}; continue}; $first=$header.Substring(0,$header.IndexOf($nl));" ^
  "$status='400 Bad Request'; $type='text/plain; charset=utf-8'; $body=$null; $verb=''; $allow='';" ^
  "if($first -cmatch '\A([A-Z]+) ([!-~]+) HTTP/1[.][01]\z'){$verb=$Matches[1]; $target=$Matches[2];" ^
  "if($verb -cnotin @('GET','HEAD')){$status='405 Method Not Allowed'; $allow='Allow: GET, HEAD'+$nl}" ^
  "elseif($target -cmatch '\A/(?!/)[^#]*\z'){$route=$target.Split([char]63)[0]; $status='404 Not Found';" ^
  "if($route -ceq '/' -or $route -ceq '/index.html'){$status='200 OK'; $type='text/html; charset=utf-8'; $body=$page}" ^
  "elseif($route -ceq '/healthz'){$status='200 OK'; $type='application/json; charset=utf-8'; $body=$health}}};" ^
  "if($null -eq $body){$body=$ascii.GetBytes($status+$nl)}; $meta='HTTP/1.0 '+$status+$nl+'Content-Type: '+$type+$nl+'Content-Length: '+$body.Length+$nl+$allow+'Cache-Control: no-store'+$nl+'X-Content-Type-Options: nosniff'+$nl+'Connection: close'+$nl+$nl;" ^
  "$head=$ascii.GetBytes($meta); $job.stream.Write($head,0,$head.Length); if($verb -cne 'HEAD'){$job.stream.Write($body,0,$body.Length)}" ^
  "} catch {}; $job.client.Close(); $queue.RemoveAt($i)}; Start-Sleep -Milliseconds 40}" ^
  "} catch {Write-Host ('分享未启动或已停止：'+$_.Exception.Message); exit 1} finally {if($listener){$listener.Stop()}; foreach($job in $queue){$job.client.Close()}}"
set "offline_share_exit=%errorlevel%"
goto finished

:bad_port
echo 使用方法：start-windows.bat 或 start-windows.bat --port 8766
set "offline_share_exit=1"
goto finished

:missing_files
echo 缺少 index.html。请将离线包完整解压，让这些文件保持在同一文件夹。
echo Missing index.html. Extract all package files into one folder.
set "offline_share_exit=1"
goto finished

:notice
echo 正在启动同一 Wi-Fi 分享。手机请打开下方显示的本机 IP 地址。
echo 仅在可信的家庭或学校专用网络中分享。系统如询问网络访问，只允许专用网络。
echo 默认端口为 8765。使用期间请保持电脑运行，并保留此窗口。
echo Keep this window open. Use the printed local IP URL on your phone.
echo 按 Ctrl+C 停止分享。Press Ctrl+C to stop.
echo.
exit /b 0

:finished
if not "%offline_share_exit%"=="0" (
    echo.
    echo 分享未能启动或已停止。请查看上方信息；也可用浏览器直接打开解压后的 index.html。
    echo Sharing could not start or has stopped. Please review the messages above.
    pause
)
popd
exit /b %offline_share_exit%
