#!/bin/bash
set -u

offline_share_pause() {
    if [ -t 0 ]; then
        printf '\n按回车关闭此窗口。Press Return to close. '
        IFS= read -r offline_share_reply || true
    fi
}

offline_share_fail() {
    printf '\n%s\n' "$1" >&2
    offline_share_pause
    exit 1
}

offline_share_dir="$(cd "$(dirname "$0")" && pwd -P)" || 
    offline_share_fail '无法进入离线包文件夹。请先完整解压，再运行此文件。'
cd "$offline_share_dir" || 
    offline_share_fail 'Cannot open the package folder. Extract the whole package first.'

if [ ! -f serve.py ] || [ ! -f index.html ]; then
    offline_share_fail '缺少 serve.py 或 index.html。请完整解压，并让它们与此脚本保持在同一文件夹。'
fi

# Finder may have a shorter PATH than an interactive Terminal session.
offline_share_python=''
offline_share_path_python="$(command -v python3 2>/dev/null || true)"
for offline_share_candidate in "$offline_share_path_python" /opt/homebrew/bin/python3 /usr/local/bin/python3; do
    [ -n "$offline_share_candidate" ] && [ -x "$offline_share_candidate" ] || continue
    # Avoid invoking Apple's developer-tools placeholder when tools are absent.
    if [ "$offline_share_candidate" = /usr/bin/python3 ] && [ -x /usr/bin/xcode-select ]; then
        /usr/bin/xcode-select -p >/dev/null 2>&1 || continue
    fi
    if "$offline_share_candidate" -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
        offline_share_python="$offline_share_candidate"
        break
    fi
done

if [ -z "$offline_share_python" ]; then
    printf '%s\n' \
        '未找到可用的 Python 3。只有同一 Wi-Fi 分享功能需要电脑预先安装 Python 3。' \
        '这台电脑仍可直接用浏览器打开 index.html，无需 Python。' \
        'Python 3 was not found. No software has been installed or downloaded.'
    offline_share_pause
    exit 1
fi

printf '%s\n' \
    '正在启动同一 Wi-Fi 分享。手机请打开下方显示的本机 IP 地址。' \
    '默认端口为 8765。使用期间请保持电脑运行，并保留此窗口。' \
    'Keep this window open. Use the printed local IP URL on your phone.' \
    '按 Control+C 停止分享。Press Control+C to stop.'
printf '\n'

"$offline_share_python" serve.py --lan "$@"
offline_share_exit=$?
if [ "$offline_share_exit" -ne 0 ]; then
    printf '\n%s\n' \
        '分享未能启动或已停止。请查看上方信息及同文件夹的使用说明。' \
        'Sharing could not start or has stopped. Please review the messages above.'
    offline_share_pause
fi
exit "$offline_share_exit"
